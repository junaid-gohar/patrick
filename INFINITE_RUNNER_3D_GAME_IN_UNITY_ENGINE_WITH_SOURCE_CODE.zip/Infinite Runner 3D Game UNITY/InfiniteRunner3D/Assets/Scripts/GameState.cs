﻿/// <summary>
/// Our game state enum
/// </summary>
public enum GameState
{
    Start,
    Playing,
    Dead
}
